from __future__ import annotations

import json
import threading
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from queue import Queue
from typing import Any
from urllib.parse import parse_qs, urlparse


@dataclass
class CallbackPayload:
    token: str
    state: str


class _CallbackHandler(BaseHTTPRequestHandler):
    server: _CallbackServer

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path != "/callback":
            self.send_error(404)
            return

        payload = self._payload_from_fields(parse_qs(parsed.query, keep_blank_values=True))
        if payload is None:
            return

        self._complete(payload)
        self.send_response(200)
        self._send_cors_headers()
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(
            b"<!DOCTYPE html><html><head><meta charset='utf-8'><title>Callabo CLI</title></head>"
            b"<body><p>Callabo CLI login completed. You can return to the terminal.</p></body></html>"
        )

    def do_OPTIONS(self) -> None:  # noqa: N802
        self.send_response(204)
        self._send_cors_headers()
        self.end_headers()

    def do_POST(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path != "/callback":
            self.send_error(404)
            return

        payload = self._payload_from_request_body()
        if payload is None:
            return

        self._complete(payload)
        self.send_response(200)
        self._send_cors_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(b'{"ok":true}')

    def _send_cors_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        if self.headers.get("Access-Control-Request-Private-Network", "").lower() == "true":
            self.send_header("Access-Control-Allow-Private-Network", "true")

    def _payload_from_request_body(self) -> CallbackPayload | None:
        content_length = int(self.headers.get("Content-Length", "0"))
        raw_body = self.rfile.read(content_length)
        content_type = self.headers.get("Content-Type", "").split(";")[0].strip().lower()

        if content_type == "application/json":
            try:
                decoded = json.loads(raw_body.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                self.send_error(400, "Invalid callback body")
                return None
            if not isinstance(decoded, dict):
                self.send_error(400, "Invalid callback body")
                return None
            fields = {key: [str(value)] for key, value in decoded.items() if value is not None}
        elif content_type == "application/x-www-form-urlencoded":
            fields = parse_qs(raw_body.decode("utf-8"), keep_blank_values=True)
        else:
            self.send_error(415, "Unsupported callback content type")
            return None

        return self._payload_from_fields(fields)

    def _payload_from_fields(self, fields: dict[str, list[str]]) -> CallbackPayload | None:
        required_fields = ["token", "state"]
        if not all(field in fields and fields[field] and fields[field][0] for field in required_fields):
            self.send_error(400, "Missing callback fields")
            return None
        return CallbackPayload(token=fields["token"][0], state=fields["state"][0])

    def _complete(self, payload: CallbackPayload) -> None:
        self.server.payload_queue.put(payload)
        threading.Thread(target=self.server.shutdown, daemon=True).start()

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A003
        return


class _CallbackServer(ThreadingHTTPServer):
    def __init__(self, server_address: tuple[str, int]):
        super().__init__(server_address, _CallbackHandler)
        self.payload_queue: Queue[CallbackPayload] = Queue(maxsize=1)


class LoopbackListener:
    def __init__(self) -> None:
        self.server = _CallbackServer(("127.0.0.1", 0))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    @property
    def redirect_uri(self) -> str:
        host, port = self.server.server_address
        return f"http://{host}:{port}/callback"

    def start(self) -> None:
        self.thread.start()

    def wait(self, timeout_seconds: float) -> CallbackPayload:
        return self.server.payload_queue.get(timeout=timeout_seconds)

    def close(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=1)

    def __enter__(self) -> LoopbackListener:
        self.start()
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()
