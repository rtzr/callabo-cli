if __name__ == "__main__":
    from callabo_cli.main import cli as run_cli

    run_cli()
