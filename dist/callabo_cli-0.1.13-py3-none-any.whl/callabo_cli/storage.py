from __future__ import annotations

import json
import uuid
from contextlib import suppress
from pathlib import Path
from typing import Any

import keyring
from keyring.errors import KeyringError, NoKeyringError, PasswordDeleteError

SERVICE_NAME = "callabo-cli"
AUTH_ENTRY = "auth"
DEVICE_ID_ENTRY = "device-id"
SECRETS_FILE = "credentials.json"


class AuthStore:
    def __init__(self) -> None:
        self.config_dir = Path.home() / ".config" / "callabo"
        self.legacy_config_dir = Path.home() / ".config" / "callabo-cli"
        self.secrets_path = self.config_dir / SECRETS_FILE
        self.pending_path = self.config_dir / "pending-login.json"
        self.default_workspace_path = self.config_dir / "default-workspace.json"
        self.legacy_pending_path = self.legacy_config_dir / "pending-login.json"
        self.legacy_default_workspace_path = self.legacy_config_dir / "default-workspace.json"

    def _read_secret(self, entry_name: str) -> str | None:
        try:
            payload = keyring.get_password(SERVICE_NAME, entry_name)
        except NoKeyringError:
            return self._read_file_secret(entry_name)
        except KeyringError as exc:
            raise RuntimeError(f"Unable to read credentials from the system keychain: {exc}") from exc
        if payload is not None:
            return payload
        return self._read_file_secret(entry_name)

    def _write_secret(self, entry_name: str, value: str) -> None:
        try:
            keyring.set_password(SERVICE_NAME, entry_name, value)
        except NoKeyringError:
            self._write_file_secret(entry_name, value)
        except KeyringError as exc:
            raise RuntimeError(f"Unable to store credentials in the system keychain: {exc}") from exc
        else:
            self._delete_file_secret(entry_name)

    def _delete_secret(self, entry_name: str) -> None:
        try:
            keyring.delete_password(SERVICE_NAME, entry_name)
        except (NoKeyringError, PasswordDeleteError):
            pass
        except KeyringError as exc:
            raise RuntimeError(f"Unable to delete credentials from the system keychain: {exc}") from exc
        self._delete_file_secret(entry_name)

    def _ensure_dir(self) -> None:
        self.config_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        with suppress(OSError):
            self.config_dir.chmod(0o700)

    def _read_json(self, path: Path) -> dict[str, Any] | None:
        if not path.exists():
            return None
        return json.loads(path.read_text())

    def _write_json(self, path: Path, payload: dict[str, Any]) -> None:
        self._ensure_dir()
        path.write_text(json.dumps(payload, indent=2, sort_keys=True))
        with suppress(OSError):
            path.chmod(0o600)

    def _read_file_secrets(self) -> dict[str, str]:
        try:
            payload = self._read_json(self.secrets_path)
        except (json.JSONDecodeError, OSError):
            return {}
        if not isinstance(payload, dict):
            return {}
        return {key: value for key, value in payload.items() if isinstance(value, str)}

    def _read_file_secret(self, entry_name: str) -> str | None:
        return self._read_file_secrets().get(entry_name)

    def _write_file_secret(self, entry_name: str, value: str) -> None:
        payload = self._read_file_secrets()
        payload[entry_name] = value
        self._write_json(self.secrets_path, payload)

    def _delete_file_secret(self, entry_name: str) -> None:
        payload = self._read_file_secrets()
        if entry_name not in payload:
            return
        del payload[entry_name]
        if payload:
            self._write_json(self.secrets_path, payload)
        elif self.secrets_path.exists():
            self.secrets_path.unlink()

    def load_auth(self) -> dict[str, Any] | None:
        payload = self._read_secret(AUTH_ENTRY)
        if payload is None:
            return None
        return json.loads(payload)

    def save_auth(self, payload: dict[str, Any]) -> None:
        self._write_secret(AUTH_ENTRY, json.dumps(payload, sort_keys=True))

    def delete_auth(self) -> None:
        self._delete_secret(AUTH_ENTRY)

    def load_device_id(self) -> str | None:
        device_id = self._read_secret(DEVICE_ID_ENTRY)
        if isinstance(device_id, str) and device_id.startswith("cli-"):
            return device_id
        return None

    def load_pending(self) -> dict[str, Any] | None:
        payload = self._read_json(self.pending_path)
        if payload is not None:
            return payload
        return self._read_json(self.legacy_pending_path)

    def save_pending(self, payload: dict[str, Any]) -> None:
        self._write_json(self.pending_path, payload)

    def delete_pending(self) -> None:
        if self.pending_path.exists():
            self.pending_path.unlink()
        if self.legacy_pending_path.exists():
            self.legacy_pending_path.unlink()

    def load_default_workspace(self) -> str | None:
        payload = self._read_json(self.default_workspace_path)
        if payload is None:
            payload = self._read_json(self.legacy_default_workspace_path)
        if payload is None:
            return None
        slug = payload.get("workspace")
        return slug if isinstance(slug, str) and slug else None

    def save_default_workspace(self, workspace_slug: str) -> None:
        self._write_json(self.default_workspace_path, {"workspace": workspace_slug})

    def delete_default_workspace(self) -> None:
        if self.default_workspace_path.exists():
            self.default_workspace_path.unlink()
        if self.legacy_default_workspace_path.exists():
            self.legacy_default_workspace_path.unlink()

    def ensure_device_id(self) -> str:
        device_id = self.load_device_id()
        if device_id is not None:
            return device_id
        new_device_id = f"cli-{uuid.uuid4()}"
        self._write_secret(DEVICE_ID_ENTRY, new_device_id)
        return new_device_id
