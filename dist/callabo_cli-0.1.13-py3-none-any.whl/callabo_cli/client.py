from __future__ import annotations

import mimetypes
from pathlib import Path
from typing import Any
from urllib.parse import quote

import httpx


class CallaboAPIError(RuntimeError):
    def __init__(self, status_code: int, detail: str) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"{status_code} {detail}")


class CallaboClient:
    def __init__(self, *, base_url: str, access_token: str | None = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.access_token = access_token
        self.client = httpx.Client(timeout=30.0)

    def close(self) -> None:
        self.client.close()

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        return headers

    def _request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        response = self.client.request(method, f"{self.base_url}{path}", headers=self._headers(), **kwargs)
        if response.is_error:
            raise CallaboAPIError(response.status_code, response.text)
        return response

    def login(
        self,
        *,
        email: str,
        password: str,
        device_id: str,
        redirect_uri: str | None = None,
        state: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"grant_type": "email", "email": email, "password": password}
        if redirect_uri is not None:
            payload["redirect_uri"] = redirect_uri
        if state is not None:
            payload["state"] = state
        response = self.client.post(
            f"{self.base_url}/v1/user/auth",
            json=payload,
            headers={"X-Device-Id": device_id},
        )
        if response.is_error:
            raise CallaboAPIError(response.status_code, response.text)
        return response.json()

    def request_magic_link(
        self,
        *,
        email: str,
        provider: str,
        redirect_uri: str,
        state: str,
    ) -> dict[str, Any]:
        response = self.client.post(
            f"{self.base_url}/v1/user/auth/magic-link",
            json={
                "email": email,
                "provider": provider,
                "redirect_uri": redirect_uri,
                "state": state,
            },
        )
        if response.is_error:
            raise CallaboAPIError(response.status_code, response.text)
        return response.json()

    def login_with_magic_link(self, *, token: str, device_id: str) -> dict[str, Any]:
        response = self.client.post(
            f"{self.base_url}/v1/magic-link/login",
            json={"token": token},
            headers={"X-Device-Id": device_id},
        )
        if response.is_error:
            raise CallaboAPIError(response.status_code, response.text)
        return response.json()

    def refresh(self, *, refresh_token: str, device_id: str | None) -> dict[str, Any]:
        headers: dict[str, str] = {}
        if device_id:
            headers["X-Device-Id"] = device_id
        response = self.client.post(
            f"{self.base_url}/v1/user/auth",
            json={"grant_type": "refresh_token", "refresh_token": refresh_token},
            headers=headers,
        )
        if response.is_error:
            raise CallaboAPIError(response.status_code, response.text)
        return response.json()

    def logout(self, *, device_id: str | None) -> None:
        headers = self._headers()
        if device_id:
            headers["X-Device-Id"] = device_id
        response = self.client.post(f"{self.base_url}/v1/user/logout", json={}, headers=headers)
        if response.is_error:
            raise CallaboAPIError(response.status_code, response.text)

    def get_me(self) -> dict[str, Any]:
        return self._request("GET", "/v1/user/me").json()

    def list_workspaces(self) -> list[dict[str, Any]]:
        return self._request("GET", "/v1/workspace").json()

    def list_active_sessions(self, *, workspace_slug: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/v1/workspaces/{workspace_slug}/recording-sessions").json()

    def list_team_active_sessions(self, *, workspace_slug: str, team_id: int) -> list[dict[str, Any]]:
        return self._request("GET", f"/v1/workspaces/{workspace_slug}/teams/{team_id}/recording-sessions").json()

    def list_records(
        self,
        *,
        workspace_slug: str,
        query: str | None = None,
        team_id: int | None = None,
        next_token: str | None = None,
        limit: int = 100,
        label_ids: list[int] | None = None,
        label_filter_condition: str = "and",
    ) -> dict[str, Any]:
        params: list[tuple[str, str | int]] = [("limit", limit)]
        if query:
            params.append(("query", query))
        if team_id is not None:
            params.append(("team_id", team_id))
        if next_token:
            params.append(("next_token", next_token))
        if label_ids:
            for label_id in label_ids:
                params.append(("label_ids", label_id))
            params.append(("label_filter_condition", label_filter_condition))
        return self._request("GET", f"/v1/workspace/{workspace_slug}/record", params=params).json()

    def get_record(self, *, workspace_slug: str, record_id: int) -> dict[str, Any]:
        return self._request("GET", f"/v1/workspace/{workspace_slug}/record/{record_id}").json()

    def create_record(self, *, workspace_slug: str, record: dict[str, Any]) -> dict[str, Any]:
        return self._request("POST", f"/v1/workspace/{workspace_slug}/record", json=record).json()

    def get_record_upload_url(self, *, workspace_slug: str, record_id: int) -> str:
        return self._request("POST", f"/v1/workspace/{workspace_slug}/record/{record_id}/upload").json()

    def upload_file_to_url(self, *, upload_url: str, file_path: Path, content_type: str | None = None) -> None:
        resolved_content_type = content_type or mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
        headers = {
            "Content-Length": str(file_path.stat().st_size),
            "Content-Type": resolved_content_type,
            "Content-Disposition": f"attachment; filename*=UTF-8''{quote(file_path.name)}",
        }
        with file_path.open("rb") as file_obj:
            response = self.client.put(upload_url, content=file_obj, headers=headers, timeout=None)
        if response.is_error:
            raise CallaboAPIError(response.status_code, response.text)

    def complete_record_upload(self, *, workspace_slug: str, record_id: int, uuid: str | None) -> dict[str, Any]:
        json_body = {"uuid": uuid} if uuid else None
        return self._request(
            "POST",
            f"/v1/workspace/{workspace_slug}/record/{record_id}/upload/complete",
            json=json_body,
        ).json()

    def get_record_download_url(self, *, workspace_slug: str, record_id: int) -> str:
        return self._request("GET", f"/v1/workspace/{workspace_slug}/record/{record_id}/download").json()

    def download_url_to_file(self, *, download_url: str, output_path: Path) -> None:
        with self.client.stream("GET", download_url, timeout=None) as response:
            if response.is_error:
                raise CallaboAPIError(response.status_code, response.text)
            with output_path.open("wb") as file_obj:
                for chunk in response.iter_bytes():
                    file_obj.write(chunk)

    def list_workspace_labels(self, *, workspace_slug: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/v1/workspace/{workspace_slug}/label").json()

    def get_record_insights(self, *, workspace_slug: str, record_id: int) -> list[dict[str, Any]]:
        return self._request("GET", f"/v1/workspace/{workspace_slug}/record/{record_id}/insight").json()

    def add_record_label(self, *, workspace_slug: str, record_id: int, label_id: int) -> None:
        self._request("POST", f"/v1/workspace/{workspace_slug}/record/{record_id}/label/{label_id}")

    def remove_record_label(self, *, workspace_slug: str, record_id: int, label_id: int) -> None:
        self._request("DELETE", f"/v1/workspace/{workspace_slug}/record/{record_id}/label/{label_id}")

    def get_session(self, *, workspace_slug: str, session_id: int) -> dict[str, Any]:
        return self._request("GET", f"/v1/workspaces/{workspace_slug}/recording-sessions/{session_id}").json()
