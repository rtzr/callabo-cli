from __future__ import annotations

import base64
import datetime as dt
import importlib.resources
import json
import os
import re
import secrets
import shutil
import sys
import uuid as uuid_lib
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from queue import Empty
from typing import Any
from urllib.parse import unquote_to_bytes, urlencode

import click
import httpx

from callabo_cli import __version__
from callabo_cli.client import CallaboAPIError, CallaboClient
from callabo_cli.listener import LoopbackListener
from callabo_cli.storage import AuthStore

DEFAULT_BASE_URL = "https://api.callabo.ai"
DEFAULT_LOGIN_URL = "https://callabo.ai/ko/login"
DEFAULT_CLI_RELEASE_API_URL = "https://api.github.com/repos/rtzr/callabo-cli/releases/latest"
DEFAULT_CLI_INSTALL_SH_URL = "https://raw.githubusercontent.com/rtzr/callabo-cli/main/dist/install.sh"
DEFAULT_CLI_INSTALL_PS1_URL = "https://raw.githubusercontent.com/rtzr/callabo-cli/main/dist/install.ps1"
CALLBACK_TIMEOUT_SECONDS = 600
OUTPUT_FORMATS = ("text", "json")
LABEL_FILTER_CHOICES = ("and", "or")
RECORD_SCOPE_CHOICES = ("workspace", "team", "private")
TRANSCRIBE_LANGUAGE_CHOICES = (
    "default",
    "detect",
    "multi",
    "ko",
    "en",
    "ja",
    "zh",
    "es",
    "fr",
    "de",
    "ru",
    "pt",
    "it",
    "ar",
    "hi",
    "id",
    "vi",
    "th",
    "nl",
)
SKILL_AGENTS = ("codex", "claude", "gemini")
SKILL_SCOPES = ("user", "project")


class MissingRemoteLogoutDeviceIdError(RuntimeError):
    pass


@dataclass(frozen=True)
class LoginSetupResult:
    default_workspace: str | None
    default_workspace_created: bool


def _auth_payload_from_token_response(
    *, base_url: str, token_payload: dict[str, Any], device_id: str, existing_auth: dict[str, Any] | None = None
) -> dict[str, Any]:
    return {
        "base_url": base_url,
        "access_token": token_payload["access_token"],
        "refresh_token": token_payload["refresh_token"],
        "created_at": token_payload["created_at"],
        "expires_in": token_payload["expires_in"],
        "device_id": device_id if device_id else (existing_auth or {}).get("device_id", ""),
    }


def _load_required_auth(store: AuthStore) -> dict[str, Any]:
    auth = store.load_auth()
    if auth is None:
        raise click.ClickException("Not logged in. Run `callabo auth login` first.")
    return auth


def _build_client_from_store(store: AuthStore) -> tuple[dict[str, Any], CallaboClient]:
    auth = _load_required_auth(store)
    return auth, CallaboClient(base_url=auth["base_url"], access_token=auth["access_token"])


def _verify_login(client: CallaboClient) -> list[dict[str, Any]]:
    client.get_me()
    return client.list_workspaces()


def _workspace_slug(workspace: dict[str, Any]) -> str | None:
    slug = workspace.get("slug") or workspace.get("temp_slug")
    return slug if isinstance(slug, str) and slug else None


def _setup_default_workspace(store: AuthStore, workspaces: list[dict[str, Any]]) -> LoginSetupResult:
    existing_default_workspace = store.load_default_workspace()
    if existing_default_workspace is not None:
        return LoginSetupResult(
            default_workspace=existing_default_workspace,
            default_workspace_created=False,
        )

    default_workspace = next(
        (workspace_slug for workspace in workspaces if (workspace_slug := _workspace_slug(workspace))),
        None,
    )
    if default_workspace is None:
        return LoginSetupResult(default_workspace=None, default_workspace_created=False)

    store.save_default_workspace(default_workspace)
    return LoginSetupResult(
        default_workspace=default_workspace,
        default_workspace_created=True,
    )


def _save_verified_auth(
    *, store: AuthStore, base_url: str, token_payload: dict[str, Any], device_id: str
) -> LoginSetupResult:
    authed_client = CallaboClient(base_url=base_url, access_token=token_payload["access_token"])
    try:
        workspaces = _verify_login(authed_client)
    finally:
        authed_client.close()
    store.save_auth(
        _auth_payload_from_token_response(
            base_url=base_url,
            token_payload=token_payload,
            device_id=device_id,
        )
    )
    return _setup_default_workspace(store, workspaces)


def _print_login_completed(setup_result: LoginSetupResult) -> None:
    click.echo("Login completed.")
    if setup_result.default_workspace_created:
        click.echo(f"Default workspace set to {setup_result.default_workspace}.")
    elif setup_result.default_workspace is not None:
        click.echo(f"Default workspace: {setup_result.default_workspace}")
    else:
        click.echo("Default workspace was not set because no accessible workspace was found.")

    click.echo("Next commands:")
    click.echo("  callabo records ls")
    click.echo("  callabo records search --query <query>")
    click.echo("  callabo records upload <file>")
    click.echo("  callabo workspace default <workspace_slug>")


def _build_cli_login_url(*, login_url: str, cli_callback_uri: str, state: str) -> str:
    separator = "&" if "?" in login_url else "?"
    return f"{login_url}{separator}{urlencode({'cli_callback_uri': cli_callback_uri, 'state': state})}"


def _complete_magic_link_login(
    *,
    store: AuthStore,
    client: CallaboClient,
    base_url: str,
    token: str,
    device_id: str,
) -> LoginSetupResult:
    loopback_login = client.login_with_magic_link(token=token, device_id=device_id)
    return _save_verified_auth(
        store=store,
        base_url=base_url,
        token_payload=loopback_login["token"],
        device_id=device_id,
    )


def _emit_json(payload: Any) -> None:
    click.echo(json.dumps(payload, indent=2, ensure_ascii=False))


def _resolve_workspace_slug(store: AuthStore, workspace_slug: str | None) -> str:
    if workspace_slug:
        return workspace_slug
    default_workspace = store.load_default_workspace()
    if default_workspace:
        return default_workspace
    raise click.ClickException(
        "Workspace is required. Pass --workspace or set a default with `callabo workspace default <slug>`."
    )


def _resolve_record_reference(
    *,
    client: CallaboClient,
    workspace_slug: str,
    session_id: int | None,
    record_id: int | None,
) -> tuple[int, dict[str, Any]]:
    if (session_id is None) == (record_id is None):
        raise click.ClickException("Provide exactly one of --session-id or --record-id.")

    if record_id is not None:
        return record_id, client.get_record(workspace_slug=workspace_slug, record_id=record_id)

    assert session_id is not None
    session = client.get_session(workspace_slug=workspace_slug, session_id=session_id)
    resolved_record_id = session.get("record", {}).get("id")
    if resolved_record_id is None:
        raise click.ClickException("Unable to resolve record_id from session.")
    return resolved_record_id, client.get_record(workspace_slug=workspace_slug, record_id=resolved_record_id)


def _save_pending_login(
    *,
    store: AuthStore,
    base_url: str,
    email: str,
    provider: str,
    redirect_uri: str,
    state: str,
) -> None:
    store.save_pending(
        {
            "base_url": base_url,
            "email": email,
            "provider": provider,
            "redirect_uri": redirect_uri,
            "state": state,
        }
    )


def _save_pending_browser_login(*, store: AuthStore, base_url: str) -> None:
    store.save_pending({"kind": "browser_login", "base_url": base_url})


def _record_labels(record: dict[str, Any]) -> list[dict[str, Any]]:
    labels = record.get("labels")
    return labels if isinstance(labels, list) else []


def _label_ids_from_record(record: dict[str, Any]) -> set[int]:
    label_ids: set[int] = set()
    for label in _record_labels(record):
        label_id = label.get("id")
        if isinstance(label_id, int):
            label_ids.add(label_id)
    return label_ids


def _matches_label_filter(record: dict[str, Any], label_ids: list[int], label_filter_condition: str) -> bool:
    if not label_ids:
        return True
    record_label_ids = _label_ids_from_record(record)
    if label_filter_condition == "or":
        return any(label_id in record_label_ids for label_id in label_ids)
    return all(label_id in record_label_ids for label_id in label_ids)


def _filter_active_records_by_labels(
    active_records: list[dict[str, Any]],
    *,
    label_ids: list[int],
    label_filter_condition: str,
) -> list[dict[str, Any]]:
    if not label_ids:
        return active_records
    return [
        item
        for item in active_records
        if _matches_label_filter(item.get("record", {}), label_ids, label_filter_condition)
    ]


def _format_label_inline(labels: list[dict[str, Any]]) -> str:
    if not labels:
        return "-"
    return ", ".join(f"{label.get('id', '-')}:#{label.get('name', '-')}" for label in labels)


def _print_label_section(items: list[dict[str, Any]]) -> None:
    if not items:
        click.echo("(none)")
        return
    for item in items:
        click.echo(
            "id={id}\tname={name}\tcolor={color}\trecord_count={record_count}".format(
                id=item.get("id", "-"),
                name=item.get("name", "-"),
                color=item.get("color", "-"),
                record_count=item.get("record_count", "-"),
            )
        )


def _print_record_labels_summary(*, record_id: int, labels: list[dict[str, Any]]) -> None:
    click.echo(f"record_id={record_id}")
    if not labels:
        click.echo("labels=(none)")
        return
    for label in labels:
        click.echo(
            "label_id={id} name={name} color={color}".format(
                id=label.get("id", "-"),
                name=label.get("name", "-"),
                color=label.get("color", "-"),
            )
        )


def _skill_source_text() -> str:
    repo_skill_path = Path(__file__).resolve().parents[2] / "SKILL.md"
    if repo_skill_path.exists():
        return repo_skill_path.read_text()
    return importlib.resources.files("callabo_cli").joinpath("SKILL.md").read_text()


def _skill_reference_texts() -> dict[Path, str]:
    repo_references_path = Path(__file__).resolve().parents[2] / "references"
    if repo_references_path.exists():
        return {
            path.relative_to(repo_references_path): path.read_text()
            for path in repo_references_path.rglob("*.md")
            if path.is_file()
        }

    package_references = importlib.resources.files("callabo_cli").joinpath("references")
    if not package_references.is_dir():
        return {}
    return {
        Path(reference.name): reference.read_text()
        for reference in package_references.iterdir()
        if reference.is_file() and reference.name.endswith(".md")
    }


def _skill_destination_path(*, agent: str, scope: str) -> Path:
    if scope == "user":
        if agent == "codex":
            return Path.home() / ".codex" / "skills" / "callabo-cli" / "SKILL.md"
        if agent == "claude":
            return Path.home() / ".claude" / "skills" / "callabo-cli" / "SKILL.md"
        return Path.home() / ".gemini" / "skills" / "callabo-cli" / "SKILL.md"

    cwd = Path.cwd()
    if agent == "codex":
        return cwd / ".codex" / "skills" / "callabo-cli" / "SKILL.md"
    if agent == "claude":
        return cwd / ".claude" / "skills" / "callabo-cli" / "SKILL.md"
    return cwd / ".gemini" / "skills" / "callabo-cli" / "SKILL.md"


def _skill_marker_paths(*, agent: str, scope: str) -> tuple[Path, ...]:
    if scope == "user":
        base = Path.home()
        if agent == "codex":
            return (base / ".codex", base / ".codex" / "config.toml")
        if agent == "claude":
            return (base / ".claude", base / ".claude" / "settings.json")
        return (base / ".gemini", base / ".gemini" / "config.yaml")

    base = Path.cwd()
    if agent == "codex":
        return (base / ".codex", base / ".codex" / "config.toml")
    if agent == "claude":
        return (base / ".claude", base / ".claude" / "settings.json")
    return (base / ".gemini", base / ".gemini" / "config.yaml")


def _detect_skill_agents(scope: str) -> list[str]:
    detected_agents: list[str] = []
    for agent in SKILL_AGENTS:
        if any(path.exists() for path in _skill_marker_paths(agent=agent, scope=scope)):
            detected_agents.append(agent)
    return detected_agents


def _print_active_record_section(title: str, items: list[dict[str, Any]]) -> None:
    click.echo(title)
    if not items:
        click.echo("  (none)")
        return
    for item in items:
        record = item.get("record", {})
        label = _display_title(record.get("title")) or f"record:{record.get('id', '-')}"
        last_message = item.get("last_message") or "-"
        labels = _format_label_inline(_record_labels(record))
        click.echo(
            (
                "  - record_id={record_id} session_id={session_id} status={status} "
                "title={title} labels={labels} last_message={last}"
            ).format(
                session_id=item.get("id", "-"),
                record_id=record.get("id", "-"),
                status=item.get("status", "-"),
                title=label,
                labels=labels,
                last=last_message,
            )
        )


def _print_record_section(title: str, items: list[dict[str, Any]]) -> None:
    click.echo(title)
    if not items:
        click.echo("  (none)")
        return
    for item in items:
        click.echo(
            (
                "  - record_id={record_id} status={status} source={source} "
                "rec_date={rec_date} title={title} labels={labels}"
            ).format(
                record_id=item.get("id", "-"),
                status=item.get("status", "-"),
                source=item.get("source", "-"),
                rec_date=item.get("rec_date", "-"),
                title=_display_title(item.get("title")) or "-",
                labels=_format_label_inline(_record_labels(item)),
            )
        )


def _display_title(value: Any) -> str | None:
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        text = value.get("text")
        if isinstance(text, str):
            return text
        html = value.get("html")
        if isinstance(html, str):
            return html
    return None


def _print_workspace_section(items: list[dict[str, Any]]) -> None:
    if not items:
        click.echo("(none)")
        return
    for workspace in items:
        click.echo(
            "{slug}\t{name}\t{role}".format(
                slug=workspace.get("slug") or workspace.get("temp_slug") or "-",
                name=workspace.get("name", "-"),
                role=workspace.get("base_role", "-"),
            )
        )


def _print_dialogs_text(*, record_id: int, dialogs: list[dict[str, Any]]) -> None:
    click.echo(f"record_id={record_id}")
    if not dialogs:
        click.echo("(none)")
        return
    for dialog in dialogs:
        click.echo(
            "[{start_at}] duration={duration} speaker={speaker} {msg}".format(
                start_at=dialog.get("start_at", "-"),
                duration=dialog.get("duration", "-"),
                speaker=dialog.get("speaker", "-"),
                msg=dialog.get("msg", ""),
            )
        )


def _print_transcript_text(*, record_id: int, dialogs: list[dict[str, Any]]) -> None:
    click.echo(f"record_id={record_id}")
    if not dialogs:
        click.echo("(none)")
        return
    for dialog in dialogs:
        click.echo(
            "[{start_at}] speaker={speaker} {msg}".format(
                start_at=dialog.get("start_at", "-"),
                speaker=dialog.get("speaker", "-"),
                msg=dialog.get("msg", ""),
            )
        )


def _print_insights_text(*, record_id: int, insights: list[dict[str, Any]]) -> None:
    click.echo(f"record_id={record_id}")
    if not insights:
        click.echo("(none)")
        return
    for insight in insights:
        click.echo("type={type} status={status} language={language}".format(**insight))
        value = insight.get("value")
        if value is not None:
            click.echo(json.dumps(value, indent=2, ensure_ascii=False))


def _print_record_detail_text(payload: dict[str, Any]) -> None:
    _emit_json(payload)


def _update_record_labels(
    *,
    action: str,
    workspace_slug: str | None,
    session_id: int | None,
    record_id: int | None,
    label_ids: tuple[int, ...],
) -> None:
    if not label_ids:
        raise click.ClickException("Provide at least one --label-id.")

    store = AuthStore()
    resolved_workspace_slug = _resolve_workspace_slug(store, workspace_slug)
    normalized_label_ids = list(dict.fromkeys(label_ids))
    _, client = _build_client_from_store(store)
    try:
        resolved_record_id, _ = _resolve_record_reference(
            client=client,
            workspace_slug=resolved_workspace_slug,
            session_id=session_id,
            record_id=record_id,
        )
        for label_id in normalized_label_ids:
            if action == "add":
                client.add_record_label(
                    workspace_slug=resolved_workspace_slug,
                    record_id=resolved_record_id,
                    label_id=label_id,
                )
            else:
                client.remove_record_label(
                    workspace_slug=resolved_workspace_slug,
                    record_id=resolved_record_id,
                    label_id=label_id,
                )
        updated_record = client.get_record(workspace_slug=resolved_workspace_slug, record_id=resolved_record_id)
        _print_record_labels_summary(record_id=resolved_record_id, labels=_record_labels(updated_record))
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


def _file_rec_date(file_path: Path) -> str:
    return dt.datetime.fromtimestamp(file_path.stat().st_mtime, tz=dt.UTC).isoformat()


def _slugify_filename_part(value: str | None) -> str:
    if not value:
        return "untitled"
    sanitized = re.sub(r"[^\w. -]+", "-", value, flags=re.UNICODE)
    sanitized = re.sub(r"\s+", "-", sanitized).strip(".- ")
    return sanitized or "untitled"


def _record_datetime_for_filename(value: Any) -> str | None:
    if isinstance(value, dt.datetime):
        return value.strftime("%Y%m%d%H%M")
    if not isinstance(value, str) or not value:
        return None
    try:
        return dt.datetime.fromisoformat(value.replace("Z", "+00:00")).strftime("%Y%m%d%H%M")
    except ValueError:
        return None


def _default_download_path(record: dict[str, Any]) -> Path:
    title = _display_title(record.get("title")) or f"record-{record.get('id', 'unknown')}"
    timestamp = _record_datetime_for_filename(record.get("rec_date"))
    if timestamp is None:
        timestamp = _record_datetime_for_filename(record.get("created_at")) or "unknown"
    return Path.cwd() / f"{_slugify_filename_part(title)}_{timestamp}.mp4"


def _write_data_uri_to_file(data_uri: str, output_path: Path) -> None:
    try:
        metadata, payload = data_uri.split(",", 1)
    except ValueError as exc:
        raise click.ClickException("Invalid data URI returned by the server.") from exc
    if ";base64" in metadata:
        output_path.write_bytes(base64.b64decode(payload))
        return
    output_path.write_bytes(unquote_to_bytes(payload))


def _configure_windows_stdio() -> None:
    if os.name != "nt":
        return

    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            reconfigure(encoding="utf-8", errors="replace")


def _is_windows() -> bool:
    return os.name == "nt"


def _version_key(version: str) -> tuple[int, ...]:
    return tuple(int(part) for part in re.findall(r"\d+", version))


def _is_newer_version(*, latest_version: str, current_version: str) -> bool:
    return _version_key(latest_version) > _version_key(current_version)


def _latest_callabo_cli_version() -> str | None:
    response = httpx.get(
        DEFAULT_CLI_RELEASE_API_URL,
        headers={"Accept": "application/vnd.github+json"},
        timeout=3.0,
    )
    response.raise_for_status()
    tag_name = response.json().get("tag_name")
    if not isinstance(tag_name, str) or not tag_name:
        return None
    return tag_name.removeprefix("v")


def _install_latest_command() -> str:
    if _is_windows():
        return f"irm {DEFAULT_CLI_INSTALL_PS1_URL} | iex"
    return f"curl -LsSf {DEFAULT_CLI_INSTALL_SH_URL} | sh"


def _version_option_callback(ctx: click.Context, _param: click.Parameter, value: bool) -> None:
    if not value or ctx.resilient_parsing:
        return

    _configure_windows_stdio()
    click.echo(f"callabo, version {__version__}")

    try:
        latest_version = _latest_callabo_cli_version()
    except Exception:
        latest_version = None

    if latest_version is None:
        click.echo("Latest version: unavailable")
        ctx.exit()

    click.echo(f"Latest version: {latest_version}")
    if _is_newer_version(latest_version=latest_version, current_version=__version__):
        click.echo("A newer Callabo CLI version is available.")
        click.echo(f"Install latest: {_install_latest_command()}")

    ctx.exit()


@click.group()
@click.option(
    "--version",
    is_flag=True,
    is_eager=True,
    expose_value=False,
    callback=_version_option_callback,
    help="Show the version and exit.",
)
def cli() -> None:
    _configure_windows_stdio()


@cli.group("skill")
def skill_group() -> None:
    pass


@skill_group.command("setup")
@click.option("--agent", type=click.Choice(SKILL_AGENTS))
@click.option("--scope", type=click.Choice(SKILL_SCOPES))
@click.option("--force", is_flag=True, help="Accepted for compatibility; setup always refreshes the skill file.")
def skill_setup(agent: str | None, scope: str | None, force: bool) -> None:
    source_text = _skill_source_text()
    reference_texts = _skill_reference_texts()
    resolved_scope = scope or "user"
    target_agents = [agent] if agent is not None else _detect_skill_agents(resolved_scope)

    if agent is None and scope is None and not target_agents:
        raise click.ClickException("No supported user-level agent configuration was detected.")
    if agent is None and scope is not None and not target_agents:
        raise click.ClickException(f"No supported {resolved_scope}-level agent configuration was detected.")

    installed_paths: list[str] = []
    for resolved_agent in target_agents:
        destination_path = _skill_destination_path(agent=resolved_agent, scope=resolved_scope)
        destination_root = destination_path.parent
        destination_root.mkdir(parents=True, exist_ok=True)
        destination_path.write_text(source_text)
        if reference_texts:
            references_root = destination_root / "references"
            if references_root.exists():
                shutil.rmtree(references_root)
            for relative_path, reference_text in reference_texts.items():
                reference_path = references_root / relative_path
                reference_path.parent.mkdir(parents=True, exist_ok=True)
                reference_path.write_text(reference_text)
        installed_paths.append(str(destination_path))

    if not installed_paths:
        raise click.ClickException("Specify --agent or initialize a supported agent first.")

    for installed_path in installed_paths:
        click.echo(installed_path)


@cli.group()
def auth() -> None:
    pass


@auth.command("login")
@click.option("--base-url", default=DEFAULT_BASE_URL, show_default=True)
@click.option("--login-url", default=DEFAULT_LOGIN_URL, envvar="CALLABO_LOGIN_URL", show_default=True)
@click.option("--email-password", is_flag=True, help="Prompt for email and password in the terminal.")
def auth_login(base_url: str, login_url: str, email_password: bool) -> None:
    if email_password:
        _auth_login_email_password(base_url=base_url)
        return

    _auth_login_browser(base_url=base_url, login_url=login_url)


def _auth_login_browser(*, base_url: str, login_url: str) -> None:
    store = AuthStore()
    store.delete_pending()
    device_id = store.ensure_device_id()
    client = CallaboClient(base_url=base_url)
    state = secrets.token_urlsafe(24)
    _save_pending_browser_login(store=store, base_url=base_url)

    try:
        with LoopbackListener() as listener:
            browser_url = _build_cli_login_url(
                login_url=login_url,
                cli_callback_uri=listener.redirect_uri,
                state=state,
            )
            click.echo("Open this URL in your browser to complete login:")
            click.echo(browser_url)
            webbrowser.open(browser_url)
            click.echo(f"Waiting for callback on {listener.redirect_uri}")
            try:
                callback = listener.wait(timeout_seconds=CALLBACK_TIMEOUT_SECONDS)
            except Empty as exc:
                raise click.ClickException("Timed out waiting for the login callback.") from exc

        if callback.state != state:
            raise click.ClickException("Received callback with an unexpected state.")

        setup_result = _complete_magic_link_login(
            store=store,
            client=client,
            base_url=base_url,
            token=callback.token,
            device_id=device_id,
        )
        store.delete_pending()
        _print_login_completed(setup_result)
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


def _auth_login_email_password(*, base_url: str) -> None:
    store = AuthStore()
    store.delete_pending()
    device_id = store.ensure_device_id()
    email = click.prompt("Email")
    password = click.prompt("Password", hide_input=True)
    client = CallaboClient(base_url=base_url)
    state = secrets.token_urlsafe(24)

    try:
        with LoopbackListener() as listener:
            response = client.login(
                email=email,
                password=password,
                device_id=device_id,
                redirect_uri=listener.redirect_uri,
                state=state,
            )
            if "token" in response:
                setup_result = _save_verified_auth(
                    store=store,
                    base_url=base_url,
                    token_payload=response["token"],
                    device_id=device_id,
                )
                _print_login_completed(setup_result)
                return

            if response.get("required_2fa_type") != "email":
                raise click.ClickException("Unsupported 2FA response.")

            _save_pending_login(
                store=store,
                base_url=base_url,
                email=response["user_email"],
                provider="email",
                redirect_uri=listener.redirect_uri,
                state=state,
            )
            click.echo("A loopback magic link email has been sent.")
            click.echo(f"Waiting for callback on {listener.redirect_uri}")
            try:
                callback = listener.wait(timeout_seconds=CALLBACK_TIMEOUT_SECONDS)
            except Empty as exc:
                raise click.ClickException("Timed out waiting for the magic link callback.") from exc
            finally:
                store.delete_pending()

        if callback.state != state:
            raise click.ClickException("Received callback with an unexpected state.")

        setup_result = _complete_magic_link_login(
            store=store,
            client=client,
            base_url=base_url,
            token=callback.token,
            device_id=device_id,
        )
        _print_login_completed(setup_result)
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


@auth.command("complete")
@click.argument("token", required=False)
@click.option("--base-url", default=None, show_default=DEFAULT_BASE_URL)
def auth_complete(token: str | None, base_url: str | None) -> None:
    store = AuthStore()
    pending = store.load_pending() or {}
    pending_base_url = pending.get("base_url")
    resolved_base_url = base_url or (pending_base_url if isinstance(pending_base_url, str) else DEFAULT_BASE_URL)
    device_id = store.ensure_device_id()
    token = token or click.prompt("Magic token", hide_input=True)
    client = CallaboClient(base_url=resolved_base_url)
    try:
        setup_result = _complete_magic_link_login(
            store=store,
            client=client,
            base_url=resolved_base_url,
            token=token,
            device_id=device_id,
        )
        store.delete_pending()
        _print_login_completed(setup_result)
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


@auth.command("resend-link")
def auth_resend_link() -> None:
    store = AuthStore()
    pending = store.load_pending()
    if pending is None:
        raise click.ClickException("No pending login session found.")
    if not {"base_url", "email", "provider", "redirect_uri", "state"} <= pending.keys():
        raise click.ClickException("No pending email magic link session found.")

    client = CallaboClient(base_url=pending["base_url"])
    try:
        client.request_magic_link(
            email=pending["email"],
            provider=pending["provider"],
            redirect_uri=pending["redirect_uri"],
            state=pending["state"],
        )
        click.echo("A new loopback magic link email has been sent.")
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


@auth.command("refresh")
def auth_refresh() -> None:
    store = AuthStore()
    auth_data = _load_required_auth(store)
    device_id = auth_data.get("device_id") or store.ensure_device_id()
    client = CallaboClient(base_url=auth_data["base_url"])
    try:
        response = client.refresh(
            refresh_token=auth_data["refresh_token"],
            device_id=device_id,
        )
        refreshed_auth = _auth_payload_from_token_response(
            base_url=auth_data["base_url"],
            token_payload=response["token"],
            device_id=device_id,
            existing_auth=auth_data,
        )
        store.save_auth(refreshed_auth)
        refreshed_client = CallaboClient(base_url=auth_data["base_url"], access_token=response["token"]["access_token"])
        try:
            _verify_login(refreshed_client)
        finally:
            refreshed_client.close()
        click.echo("Tokens refreshed.")
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


def _remote_logout_device_id(store: AuthStore, auth_data: dict[str, Any]) -> str:
    device_id = auth_data.get("device_id")
    if isinstance(device_id, str) and device_id:
        return device_id
    device_id = store.load_device_id()
    if device_id is not None:
        return device_id
    raise MissingRemoteLogoutDeviceIdError("saved CLI device id is missing")


def _remote_logout(store: AuthStore, auth_data: dict[str, Any]) -> None:
    device_id = _remote_logout_device_id(store, auth_data)

    client = CallaboClient(base_url=auth_data["base_url"], access_token=auth_data["access_token"])
    try:
        try:
            client.logout(device_id=device_id)
        except CallaboAPIError as exc:
            if exc.status_code != 401:
                raise
            response = client.refresh(refresh_token=auth_data["refresh_token"], device_id=device_id)
            store.save_auth(
                _auth_payload_from_token_response(
                    base_url=auth_data["base_url"],
                    token_payload=response["token"],
                    device_id=device_id,
                    existing_auth=auth_data,
                )
            )
            client.access_token = response["token"]["access_token"]
            client.logout(device_id=device_id)
    finally:
        client.close()


@auth.command("logout")
def auth_logout() -> None:
    store = AuthStore()
    auth_data = store.load_auth()
    local_only = False
    if auth_data is not None:
        try:
            _remote_logout(store, auth_data)
        except MissingRemoteLogoutDeviceIdError as exc:
            local_only = True
            click.echo(f"Warning: Remote logout skipped ({exc}). Removing local credentials only.", err=True)
        except Exception as exc:
            raise click.ClickException(f"Remote logout failed: {exc}") from exc

    store.delete_auth()
    store.delete_pending()
    store.delete_default_workspace()
    click.echo("Local credentials removed." if local_only else "Logged out.")


@cli.group("workspace")
def workspace_group() -> None:
    pass


@cli.group("labels")
def labels_group() -> None:
    pass


@labels_group.command("ls")
@click.option("--workspace", "workspace_slug")
@click.option("--format", "output_format", type=click.Choice(OUTPUT_FORMATS), default="text", show_default=True)
def labels_ls(workspace_slug: str | None, output_format: str) -> None:
    store = AuthStore()
    resolved_workspace_slug = _resolve_workspace_slug(store, workspace_slug)
    _, client = _build_client_from_store(store)
    try:
        labels = client.list_workspace_labels(workspace_slug=resolved_workspace_slug)
        payload = {"workspace": resolved_workspace_slug, "labels": labels}
        if output_format == "json":
            _emit_json(payload)
        else:
            _print_label_section(labels)
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


@workspace_group.command("ls")
@click.option("--format", "output_format", type=click.Choice(OUTPUT_FORMATS), default="text", show_default=True)
def workspace_ls(output_format: str) -> None:
    store = AuthStore()
    _, client = _build_client_from_store(store)
    try:
        workspaces = client.list_workspaces()
        if output_format == "json":
            _emit_json(workspaces)
        else:
            _print_workspace_section(workspaces)
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


@workspace_group.command("default")
@click.argument("workspace_slug", required=False)
@click.option("--clear", is_flag=True, help="Clear the saved default workspace.")
@click.option("--format", "output_format", type=click.Choice(OUTPUT_FORMATS), default="text", show_default=True)
def workspace_default(workspace_slug: str | None, clear: bool, output_format: str) -> None:
    store = AuthStore()
    if clear:
        store.delete_default_workspace()
        if output_format == "json":
            _emit_json({"workspace": None})
        else:
            click.echo("Default workspace cleared.")
        return

    if workspace_slug is None:
        default_workspace = store.load_default_workspace()
        if output_format == "json":
            _emit_json({"workspace": default_workspace})
        else:
            click.echo(default_workspace or "(none)")
        return

    _, client = _build_client_from_store(store)
    try:
        workspaces = client.list_workspaces()
        matched_workspace = next(
            (
                workspace
                for workspace in workspaces
                if workspace_slug in {workspace.get("slug"), workspace.get("temp_slug")}
            ),
            None,
        )
        if matched_workspace is None:
            raise click.ClickException(f"Workspace not found or not accessible: {workspace_slug}")
        resolved_slug = matched_workspace.get("slug") or matched_workspace.get("temp_slug")
        if not isinstance(resolved_slug, str) or not resolved_slug:
            raise click.ClickException("Workspace slug is missing.")
        store.save_default_workspace(resolved_slug)
        if output_format == "json":
            _emit_json({"workspace": resolved_slug})
        else:
            click.echo(f"Default workspace set to {resolved_slug}.")
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


@cli.group("records")
def records_group() -> None:
    pass


@records_group.group("labels")
def records_labels_group() -> None:
    pass


@records_labels_group.command("add")
@click.option("--workspace", "workspace_slug")
@click.option("--session-id", type=int)
@click.option("--record-id", type=int)
@click.option("--label-id", "label_ids", type=int, multiple=True, required=True)
def records_labels_add(
    workspace_slug: str | None,
    session_id: int | None,
    record_id: int | None,
    label_ids: tuple[int, ...],
) -> None:
    _update_record_labels(
        action="add",
        workspace_slug=workspace_slug,
        session_id=session_id,
        record_id=record_id,
        label_ids=label_ids,
    )


@records_labels_group.command("remove")
@click.option("--workspace", "workspace_slug")
@click.option("--session-id", type=int)
@click.option("--record-id", type=int)
@click.option("--label-id", "label_ids", type=int, multiple=True, required=True)
def records_labels_remove(
    workspace_slug: str | None,
    session_id: int | None,
    record_id: int | None,
    label_ids: tuple[int, ...],
) -> None:
    _update_record_labels(
        action="remove",
        workspace_slug=workspace_slug,
        session_id=session_id,
        record_id=record_id,
        label_ids=label_ids,
    )


@records_group.command("ls")
@click.option("--workspace", "workspace_slug")
@click.option("--team-id", type=int)
@click.option("--label-id", "label_ids", type=int, multiple=True)
@click.option(
    "--label-filter",
    "label_filter_condition",
    type=click.Choice(LABEL_FILTER_CHOICES),
    default="and",
    show_default=True,
)
@click.option("--format", "output_format", type=click.Choice(OUTPUT_FORMATS), default="text", show_default=True)
def records_ls(
    workspace_slug: str | None,
    team_id: int | None,
    label_ids: tuple[int, ...],
    label_filter_condition: str,
    output_format: str,
) -> None:
    store = AuthStore()
    resolved_workspace_slug = _resolve_workspace_slug(store, workspace_slug)
    normalized_label_ids = list(dict.fromkeys(label_ids))
    _, client = _build_client_from_store(store)
    try:
        if team_id is None:
            active_records = client.list_active_sessions(workspace_slug=resolved_workspace_slug)
        else:
            active_records = client.list_team_active_sessions(workspace_slug=resolved_workspace_slug, team_id=team_id)
        filtered_active = _filter_active_records_by_labels(
            active_records,
            label_ids=normalized_label_ids,
            label_filter_condition=label_filter_condition,
        )
        records = client.list_records(
            workspace_slug=resolved_workspace_slug,
            team_id=team_id,
            label_ids=normalized_label_ids,
            label_filter_condition=label_filter_condition,
        )
        payload = {
            "workspace": resolved_workspace_slug,
            "team_id": team_id,
            "label_ids": normalized_label_ids,
            "label_filter_condition": label_filter_condition,
            "active_records": filtered_active,
            "completed_records": records.get("items", []),
        }
        if output_format == "json":
            _emit_json(payload)
        else:
            _print_active_record_section("Active Records", filtered_active)
            _print_record_section("Completed Records", records.get("items", []))
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


@records_group.command("search")
@click.option("--workspace", "workspace_slug")
@click.option("--query", required=True)
@click.option("--team-id", type=int)
@click.option("--label-id", "label_ids", type=int, multiple=True)
@click.option(
    "--label-filter",
    "label_filter_condition",
    type=click.Choice(LABEL_FILTER_CHOICES),
    default="and",
    show_default=True,
)
@click.option("--format", "output_format", type=click.Choice(OUTPUT_FORMATS), default="text", show_default=True)
def records_search(
    workspace_slug: str | None,
    query: str,
    team_id: int | None,
    label_ids: tuple[int, ...],
    label_filter_condition: str,
    output_format: str,
) -> None:
    store = AuthStore()
    resolved_workspace_slug = _resolve_workspace_slug(store, workspace_slug)
    _, client = _build_client_from_store(store)
    query_lower = query.casefold()
    normalized_label_ids = list(dict.fromkeys(label_ids))
    try:
        if team_id is None:
            active_records = client.list_active_sessions(workspace_slug=resolved_workspace_slug)
        else:
            active_records = client.list_team_active_sessions(workspace_slug=resolved_workspace_slug, team_id=team_id)
        filtered_active = [
            item
            for item in active_records
            if query_lower in str(item.get("last_message", "")).casefold()
            or query_lower in (_display_title(item.get("record", {}).get("title")) or "").casefold()
        ]
        filtered_active = _filter_active_records_by_labels(
            filtered_active,
            label_ids=normalized_label_ids,
            label_filter_condition=label_filter_condition,
        )
        records = client.list_records(
            workspace_slug=resolved_workspace_slug,
            team_id=team_id,
            query=query,
            label_ids=normalized_label_ids,
            label_filter_condition=label_filter_condition,
        )
        payload = {
            "workspace": resolved_workspace_slug,
            "team_id": team_id,
            "query": query,
            "label_ids": normalized_label_ids,
            "label_filter_condition": label_filter_condition,
            "active_records": filtered_active,
            "completed_records": records.get("items", []),
        }
        if output_format == "json":
            _emit_json(payload)
        else:
            _print_active_record_section("Active Records", filtered_active)
            _print_record_section("Completed Records", records.get("items", []))
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


@records_group.command("show")
@click.option("--workspace", "workspace_slug")
@click.option("--session-id", type=int)
@click.option("--record-id", type=int)
@click.option("--format", "output_format", type=click.Choice(OUTPUT_FORMATS), default="text", show_default=True)
def records_show(workspace_slug: str, session_id: int | None, record_id: int | None, output_format: str) -> None:
    if (session_id is None) == (record_id is None):
        raise click.ClickException("Provide exactly one of --session-id or --record-id.")

    store = AuthStore()
    resolved_workspace_slug = _resolve_workspace_slug(store, workspace_slug)
    _, client = _build_client_from_store(store)
    try:
        payload = (
            client.get_session(workspace_slug=resolved_workspace_slug, session_id=session_id)
            if session_id is not None
            else client.get_record(workspace_slug=resolved_workspace_slug, record_id=record_id)
        )
        if output_format == "json":
            _emit_json(payload)
        else:
            _print_record_detail_text(payload)
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


@records_group.command("dialogs")
@click.option("--workspace", "workspace_slug")
@click.option("--session-id", type=int)
@click.option("--record-id", type=int)
@click.option("--format", "output_format", type=click.Choice(OUTPUT_FORMATS), default="text", show_default=True)
def records_dialogs(workspace_slug: str, session_id: int | None, record_id: int | None, output_format: str) -> None:
    store = AuthStore()
    resolved_workspace_slug = _resolve_workspace_slug(store, workspace_slug)
    _, client = _build_client_from_store(store)
    try:
        resolved_record_id, record = _resolve_record_reference(
            client=client,
            workspace_slug=resolved_workspace_slug,
            session_id=session_id,
            record_id=record_id,
        )
        dialogs = record.get("dialogs") or []
        payload = {"record_id": resolved_record_id, "dialogs": dialogs}
        if output_format == "json":
            _emit_json(payload)
        else:
            _print_dialogs_text(record_id=resolved_record_id, dialogs=dialogs)
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


@records_group.command("transcript")
@click.option("--workspace", "workspace_slug")
@click.option("--session-id", type=int)
@click.option("--record-id", type=int)
@click.option("--format", "output_format", type=click.Choice(OUTPUT_FORMATS), default="text", show_default=True)
def records_transcript(workspace_slug: str, session_id: int | None, record_id: int | None, output_format: str) -> None:
    store = AuthStore()
    resolved_workspace_slug = _resolve_workspace_slug(store, workspace_slug)
    _, client = _build_client_from_store(store)
    try:
        resolved_record_id, record = _resolve_record_reference(
            client=client,
            workspace_slug=resolved_workspace_slug,
            session_id=session_id,
            record_id=record_id,
        )
        dialogs = record.get("dialogs") or []
        payload = {"record_id": resolved_record_id, "dialogs": dialogs}
        if output_format == "json":
            _emit_json(payload)
        else:
            _print_transcript_text(record_id=resolved_record_id, dialogs=dialogs)
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


@records_group.command("insights")
@click.option("--workspace", "workspace_slug")
@click.option("--session-id", type=int)
@click.option("--record-id", type=int)
@click.option("--format", "output_format", type=click.Choice(OUTPUT_FORMATS), default="text", show_default=True)
def records_insights(workspace_slug: str, session_id: int | None, record_id: int | None, output_format: str) -> None:
    store = AuthStore()
    resolved_workspace_slug = _resolve_workspace_slug(store, workspace_slug)
    _, client = _build_client_from_store(store)
    try:
        resolved_record_id, _ = _resolve_record_reference(
            client=client,
            workspace_slug=resolved_workspace_slug,
            session_id=session_id,
            record_id=record_id,
        )
        insights = client.get_record_insights(workspace_slug=resolved_workspace_slug, record_id=resolved_record_id)
        payload = {"record_id": resolved_record_id, "insights": insights}
        if output_format == "json":
            _emit_json(payload)
        else:
            _print_insights_text(record_id=resolved_record_id, insights=insights)
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


@records_group.command("upload")
@click.argument("file_path", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.option("--workspace", "workspace_slug")
@click.option("--title")
@click.option("--scope", type=click.Choice(RECORD_SCOPE_CHOICES), default="private", show_default=True)
@click.option("--team-id", "team_ids", type=int, multiple=True)
@click.option("--accessible-team-id", "accessible_team_ids", type=int, multiple=True)
@click.option("--accessible-user-id", "accessible_user_ids", type=int, multiple=True)
@click.option("--label-id", "label_ids", type=int, multiple=True)
@click.option(
    "--language",
    "transcribe_language",
    type=click.Choice(TRANSCRIBE_LANGUAGE_CHOICES),
    default="default",
    show_default=True,
)
@click.option("--format", "output_format", type=click.Choice(OUTPUT_FORMATS), default="text", show_default=True)
def records_upload(
    file_path: Path,
    workspace_slug: str | None,
    title: str | None,
    scope: str,
    team_ids: tuple[int, ...],
    accessible_team_ids: tuple[int, ...],
    accessible_user_ids: tuple[int, ...],
    label_ids: tuple[int, ...],
    transcribe_language: str,
    output_format: str,
) -> None:
    store = AuthStore()
    resolved_workspace_slug = _resolve_workspace_slug(store, workspace_slug)
    upload_uuid = str(uuid_lib.uuid4())
    record_payload: dict[str, Any] = {
        "uuid": upload_uuid,
        "source": "manual_upload",
        "upload_source": "cli",
        "filesize": file_path.stat().st_size,
        "duration": None,
        "rec_date": _file_rec_date(file_path),
        "scope": scope,
        "transcribe_language": transcribe_language,
        "save_media": "default",
        "save_dialog": "default",
        "filename": file_path.name,
    }
    if title:
        record_payload["title"] = title
    if team_ids:
        record_payload["team_ids"] = list(dict.fromkeys(team_ids))
    if accessible_team_ids:
        record_payload["accessible_team_ids"] = list(dict.fromkeys(accessible_team_ids))
    if accessible_user_ids:
        record_payload["accessible_user_ids"] = list(dict.fromkeys(accessible_user_ids))
    if label_ids:
        record_payload["label_ids"] = list(dict.fromkeys(label_ids))

    _, client = _build_client_from_store(store)
    try:
        created_record = client.create_record(workspace_slug=resolved_workspace_slug, record=record_payload)
        record_id = created_record.get("id")
        if not isinstance(record_id, int):
            raise click.ClickException("Created record response is missing record id.")
        upload_url = client.get_record_upload_url(workspace_slug=resolved_workspace_slug, record_id=record_id)
        client.upload_file_to_url(upload_url=upload_url, file_path=file_path)
        completed_record = client.complete_record_upload(
            workspace_slug=resolved_workspace_slug,
            record_id=record_id,
            uuid=upload_uuid,
        )
        if output_format == "json":
            _emit_json({"workspace": resolved_workspace_slug, "record": completed_record})
        else:
            click.echo(
                "Uploaded record_id={record_id} status={status}".format(
                    record_id=completed_record.get("id", record_id),
                    status=completed_record.get("status", "-"),
                )
            )
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()


@records_group.command("download")
@click.option("--workspace", "workspace_slug")
@click.option("--record-id", type=int, required=True)
@click.option("--output", "output_path", type=click.Path(dir_okay=False, path_type=Path))
@click.option("--force", is_flag=True, help="Overwrite the output file if it already exists.")
def records_download(
    workspace_slug: str | None,
    record_id: int,
    output_path: Path | None,
    force: bool,
) -> None:
    store = AuthStore()
    resolved_workspace_slug = _resolve_workspace_slug(store, workspace_slug)
    _, client = _build_client_from_store(store)
    try:
        record = client.get_record(workspace_slug=resolved_workspace_slug, record_id=record_id)
        destination = output_path or _default_download_path(record)
        if destination.exists() and not force:
            raise click.ClickException(f"Output file already exists: {destination}")
        if not destination.parent.exists():
            raise click.ClickException(f"Output directory does not exist: {destination.parent}")

        download_url = client.get_record_download_url(workspace_slug=resolved_workspace_slug, record_id=record_id)
        if download_url.startswith("data:"):
            _write_data_uri_to_file(download_url, destination)
        else:
            client.download_url_to_file(download_url=download_url, output_path=destination)
        click.echo(str(destination))
    except CallaboAPIError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()
